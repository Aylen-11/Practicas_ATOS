package eventosweb.modelo.dto;

import java.util.List;
import java.util.Objects;

import eventosweb.modelo.entities.Reserva;

public class ReservaDto {
	private int idReserva;
	private String email;
	private String nombre;//usuario
	private String apellidos;
	private int idEvento;
	private String nombreEvento;
	private int aforoMaximo;
	private double precioEvento;
	private int cantidad;
	private  double precioVenta; //precio Reserva
	
	
	
	public ReservaDto() {
		super();
	}


	@Override
	public String toString() {
		return "ReservaDto [idReserva=" + idReserva + ", email=" + email + ", nombre=" + nombre + ", apellidos="
				+ apellidos + ", idEvento=" + idEvento + ", nombreEvento=" + nombreEvento + ", aforoMaximo="
				+ aforoMaximo + ", precioEvento=" + precioEvento + ", cantidad=" + cantidad + ", precioVenta="
				+ precioVenta + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(idReserva);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReservaDto other = (ReservaDto) obj;
		return idReserva == other.idReserva;
	}

	public int getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(int idReserva) {
		this.idReserva = idReserva;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public int getIdEvento() {
		return idEvento;
	}

	public void setIdEvento(int idEvento) {
		this.idEvento = idEvento;
	}

	public String getNombreEvento() {
		return nombreEvento;
	}

	public void setNombreEvento(String nombreEvento) {
		this.nombreEvento = nombreEvento;
	}

	public int getAforoMaximo() {
		return aforoMaximo;
	}

	public void setAforoMaximo(int aforoMaximo) {
		this.aforoMaximo = aforoMaximo;
	}

	public double getPrecioEvento() {
		return precioEvento;
	}

	public void setPrecioEvento(double precioEvento) {
		this.precioEvento = precioEvento;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}

	public ReservaDto(int idReserva, String email, String nombre, String apellidos, int idEvento, String nombreEvento,
			int aforoMaximo, double precioEvento, int cantidad, double precioVenta) {
		super();
		this.idReserva = idReserva;
		this.email = email;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.idEvento = idEvento;
		this.nombreEvento = nombreEvento;
		this.aforoMaximo = aforoMaximo;
		this.precioEvento = precioEvento;
		this.cantidad = cantidad;
		this.precioVenta = precioVenta;
	}

	public static ReservaDto convert (Reserva reserva) {
		
		ReservaDto rdto = new ReservaDto();
		rdto.setAforoMaximo(reserva.getEvento().getAforoMaximo()); 
		rdto.setApellidos(reserva.getUsuario().getApellidos());
		rdto.setCantidad(reserva.getCantidad());
		rdto.setEmail(reserva.getUsuario().getEmail()); 
		rdto.setIdEvento(reserva.getEvento().getIdEvento());
		rdto.setIdReserva(reserva.getIdReserva());
		rdto.setNombre(reserva.getUsuario().getNombre()); 
		rdto.setNombreEvento(reserva.getEvento().getNombre()); 
		rdto.setPrecioVenta(reserva.getPrecioVenta()); 
		rdto.setPrecioEvento(reserva.getEvento().getPrecio()); 
		
		return rdto;
	}
	
	public static List<ReservaDto> convertList(List<Reserva> reservas){
		return reservas.stream()
				.map(ele -> ReservaDto.convert(ele))
				.toList();
	}
	
	
}
