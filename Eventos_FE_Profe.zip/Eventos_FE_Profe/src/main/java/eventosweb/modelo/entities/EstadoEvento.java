package eventosweb.modelo.entities;

public enum EstadoEvento {
	ACTIVO, 
	TERMINADO,
	CANCELADO

}
