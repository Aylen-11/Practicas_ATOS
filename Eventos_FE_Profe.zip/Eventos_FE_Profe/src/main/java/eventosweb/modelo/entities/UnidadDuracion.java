package eventosweb.modelo.entities;

public enum UnidadDuracion {
	DIAS,
	HORAS

}
