package eventosweb.modelo.entities;

public enum Destacado {
	S,
	N

}
