package eventosweb.modelo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eventosweb.modelo.entities.Usuario;
import eventosweb.modelo.repository.UsuarioRepository;
import eventosweb.restcontroller.UsuarioRestController;

@Service 

public class UsuarioDaoImplDataJpa implements UsuarioDao  {
	
	@Autowired
	private UsuarioRepository urepo;

	@Override
	public List<Usuario> todos() {
		return urepo.findAll();
	}

	@Override
	public List<Usuario> porNombreContain(String cadena) {
		return urepo.findByNombreContaining(cadena);
	}

	@Override
	public Usuario insertOne(Usuario usuario) {
		try {
			return urepo.save(usuario);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Usuario buscarUno(Integer idUsuario) {
		return urepo.findById(idUsuario).orElse(null);
	}

	@Override
	public int eliminarEvento(Integer idUsuario) {
		int filas = 0;
		if(urepo.existsById(idUsuario)) {
			try {
				urepo.deleteById(idUsuario);
				filas = 1;
			} catch (Exception e) {
				System.out.println(e.getMessage());
				filas = -1;
			}
		}else {
			filas = 0;
		}
		return filas;
	}


}
