package eventosweb.modelo.dao;

import java.util.List;

import eventosweb.modelo.entities.Reserva;

public interface ReservaDao {
	List<Reserva> buscarPorEvento(int idEvento);
	List<Reserva> buscarPorIdUsuario(int idUsuario);
	List<Reserva> buscarPorEmail(int email);
	Reserva buscarUno(int idReserva);
}
