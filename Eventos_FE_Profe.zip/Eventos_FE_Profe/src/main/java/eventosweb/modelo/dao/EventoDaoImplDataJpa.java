package eventosweb.modelo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eventosweb.modelo.entities.Evento;
import eventosweb.modelo.repository.EventoRepository;
@Service
public class EventoDaoImplDataJpa implements EventoDao{

	@Autowired
	private EventoRepository erepo;

	@Override
	public List<Evento> todos() {
		return erepo.findAll();
		
	}

	@Override
	public List<Evento> porNombreContain(String cadena) {
		return erepo.findByNombreContaining(cadena);
	}

	@Override
	public Evento insertOne(Evento evento) {
		try {
			return erepo.save(evento);
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Evento buscarUno(Integer idEvento) {
		return erepo.findById(idEvento).orElse(null);
	}

	@Override
	public int eliminarEvento(Integer idEvento) {
		int filas = 0;
		if (erepo.existsById(idEvento)) {
			try {
				erepo.deleteById(idEvento);
				filas = 1;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				filas = -1;
			}
		}else 
			filas = 0;
		
		return filas;
	}

	@Override
	public Evento modificarUno(Evento evento) {
		if ( erepo.findById(evento.getIdEvento()) != null){
			return erepo.save(evento);
		}
		return evento;
	}
	
}
