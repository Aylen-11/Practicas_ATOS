package eventosweb.modelo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eventosweb.modelo.entities.Reserva;
import eventosweb.modelo.repository.ReservaRepository;

@Service

public class ReservaDaoImplDataJpaMy8 implements ReservaDao{
	
	@Autowired
	private ReservaRepository rrepo;

	@Override
	public List<Reserva> buscarPorEvento(int idEvento) {
		return rrepo.findByEvento_IdEvento(idEvento);
	}

	@Override
	public List<Reserva> buscarPorIdUsuario(int idUsuario) {
		return rrepo.findByUsuario_IdUsuario(idUsuario);
	}

	@Override
	public List<Reserva> buscarPorEmail(int email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Reserva buscarUno(Integer idReserva) {
		return rrepo.findById(idReserva).orElse(null);
	}

	@Override
	public int eliminarUno(int idReserva) {
		int filas = 0;
		if (rrepo.existsById(idReserva)) {
			try {
				rrepo.deleteById(idReserva);
				filas = 1;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				filas = -1;
			}
		}else 
			filas = 0;
		
		return filas;
	}

	@Override
	public Reserva modificarUno(Reserva reserva) {
		if (rrepo.findById(reserva.getIdReserva()) != null) {
			return rrepo.save(reserva);
		}
		return reserva;
	}

}
