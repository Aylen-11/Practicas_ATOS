package eventosweb.modelo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eventosweb.modelo.entities.Reserva;
import eventosweb.modelo.repository.ReservaRepository;

@Service

public class ReservaDaoImplDataJpaMy8 implements ReservaDao{
	
	@Autowired
	private ReservaRepository rrepo;

	@Override
	public List<Reserva> buscarPorEvento(int idEvento) {
		// TODO Auto-generated method stub
		return rrepo.findByEvento_IdEvento(idEvento);
	}

	@Override
	public List<Reserva> buscarPorIdUsuario(int idUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Reserva> buscarPorEmail(int email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Reserva buscarUno(int idReserva) {
		// TODO Auto-generated method stub
		return null;
	}

}
