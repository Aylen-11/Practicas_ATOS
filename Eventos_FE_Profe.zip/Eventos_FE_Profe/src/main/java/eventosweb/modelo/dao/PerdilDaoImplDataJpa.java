package eventosweb.modelo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eventosweb.modelo.entities.Perfil;
import eventosweb.modelo.repository.PerfilRepository;
@Service
public class PerdilDaoImplDataJpa implements PerfilDao{

    
	@Autowired
	private PerfilRepository prepo;

    
	@Override
	public List<Perfil> todos() {
		return prepo.findAll();
	}
	
	@Override
	public List<Perfil> porNombreContain(String cadena) {
		return prepo.findByNombreContaining(cadena);
	}
	
	@Override
	public Perfil insertOne(Perfil perfil) {
		try {
			return prepo.save(perfil);
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public Perfil buscarUno(Integer idPerfil) {
		return prepo.findById(idPerfil).orElse(null);
	}
	
	@Override
	public int eliminarPerfil(Integer idPerfil) {
		int filas = 0;
		if (prepo.existsById(idPerfil)) {
			try {
				prepo.deleteById(idPerfil);
				filas = 1;
				
			} catch (Exception e) {
				System.out.println(e.getMessage());
				filas = -1;
			}
		}else 
			filas = 0;
		
		return filas;
		
	}

}
