package eventosweb.modelo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import eventosweb.modelo.entities.Evento;
import eventosweb.modelo.entities.Perfil;

public interface EventoRepository extends JpaRepository<Evento, Integer> {

	public List<Evento> findByNombreContaining(String cadena);

}
