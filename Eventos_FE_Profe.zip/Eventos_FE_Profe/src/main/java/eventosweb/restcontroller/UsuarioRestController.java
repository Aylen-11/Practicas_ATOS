package eventosweb.restcontroller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eventosweb.modelo.dao.PerfilDao;
import eventosweb.modelo.dao.UsuarioDao;
import eventosweb.modelo.entities.Evento;
import eventosweb.modelo.entities.Usuario;
import eventosweb.modelo.repository.UsuarioRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/usuarios")
public class UsuarioRestController {
	@Autowired
	private UsuarioDao udao;
	
	@Autowired
	private PerfilDao pdao;
	
	@GetMapping("/todos")
	public List<Usuario> todos(){
		return udao.todos();
	}
	
	@GetMapping("/nombre/{cadena}")
	public List<Usuario> cadena(@PathVariable String cadena){
		return udao.porNombreContain(cadena);
	}
	 
	@GetMapping("/emailypass/{cadenaEmail}/{cadenaPass}")
	public List<Usuario> cadenaEmailPass(@PathVariable String cadenaEmail, @PathVariable String cadenaPass){
		return udao.porEmailYPassword(cadenaEmail, cadenaPass);
	}
	
	@GetMapping("/uno/{idUsuario}")
	public Usuario uno(@PathVariable Integer idUsuario) {
		return udao.buscarUno(idUsuario);
	}
	
	@PostMapping("/alta")//solo se da alta al cliente
	public Usuario alta(@RequestBody Usuario usuario) {
		 usuario.setPerfil(pdao.buscarUno(2));
		 usuario.setEnabled(1);
		 usuario.setFechaRegistro(LocalDate.now());
		return udao.insertOne(usuario);
	}
	 
	@DeleteMapping("/eliminar/{idUsuario}")
	public Integer eliminar(@PathVariable("idUsuario") int idUsuario) {
		return udao.eliminarEvento(idUsuario);
	 }

}
