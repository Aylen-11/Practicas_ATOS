package eventosweb.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eventosweb.modelo.dao.ReservaDao;
import eventosweb.modelo.dto.ReservaDto;
import eventosweb.modelo.entities.Reserva;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping ("/reservas")
public class ReservaRestController {
	
	@Autowired
	private ReservaDao rdao;
	
	@GetMapping("/evento/{idEvento}")
	public List<ReservaDto> porEvento(@PathVariable int idEvento){
		
		return ReservaDto.convertList(rdao.buscarPorEvento(idEvento));
		
	}

}
