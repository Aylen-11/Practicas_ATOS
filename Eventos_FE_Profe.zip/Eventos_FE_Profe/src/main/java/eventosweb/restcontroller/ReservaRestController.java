package eventosweb.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import eventosweb.modelo.dao.ReservaDao;
import eventosweb.modelo.dto.ReservaDto;
import eventosweb.modelo.entities.Reserva;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping ("/reservas")
public class ReservaRestController {
	
	@Autowired
	private ReservaDao rdao;
	
	@GetMapping("/evento/{idEvento}")
	public List<ReservaDto> porEvento(@PathVariable int idEvento){
		
		return ReservaDto.convertList(rdao.buscarPorEvento(idEvento));
		
	}
	
	@GetMapping("/usuario/{idUsuario}")
	public List<Reserva> porIdUsuario(@PathVariable int idUsuario){
		return rdao.buscarPorIdUsuario(idUsuario);
	}
	
	@GetMapping("/uno/{idReserva}")
	public Reserva buscarUno(@PathVariable Integer idReserva) {
		return rdao.buscarUno(idReserva);
	}
	
	@DeleteMapping("/eliminar/{idReserva}")
	public Integer elimarUno(@PathVariable ("idReserva") int idReserva ) {
		return rdao.eliminarUno(idReserva);
	}
	
	@PutMapping("/modificar/{idReserva}")
	public Reserva modificarUno(@PathVariable int idReserva, @RequestBody Reserva reserva) {
		reserva.setIdReserva(idReserva);
		return rdao.modificarUno(reserva);
	}

}
