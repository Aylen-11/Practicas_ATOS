package eventosweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventosFeProfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosFeProfeApplication.class, args);
	}

}
